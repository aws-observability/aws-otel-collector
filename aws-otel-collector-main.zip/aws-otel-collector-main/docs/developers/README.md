# Developer Documentation

Build

- [Binary](build-aoc.md)
- [Docker Image](build-docker.md)

Container Insights for Prometheus Support

- [EKS](container-insight-install-aoc.md)
- [ECS](container-insights-ecs-prometheus.md)

EC2

- [Linux RPM](linux-rpm-demo.md)
- [Windows](windows-other-demo.md)